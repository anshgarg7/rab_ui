import React, { Component } from "react";
import { Breadcrumb, Container, Row, Col, Form, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import '../../../assets/css/style.css'
import MultiDay from "./activityDay/multipleDay";
import SingleDay from "./activityDay/singleDay";
import http from "../../../Helper/http";
import { Box, Typography, Modal } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import Files from 'react-files';
import { FileUploader } from "react-drag-drop-files";
import MapPicker from 'react-google-map-picker'
import upload from "../../../assets/images/upload.png"
import { Country, State, City } from 'country-state-city';
import ListItemText from '@mui/material/ListItemText';
// import Select from '@mui/material/Select';
import Checkbox from '@mui/material/Checkbox';
import SweetAlert from 'react-bootstrap-sweetalert';

import {
  geocodeByAddress,
  getLatLng,
} from 'react-places-autocomplete';
import GoogleMapReact from 'google-map-react';

// const AnyReactComponent = ({ text }) => <div>{text}</div>;
import PlacesAutocomplete from 'react-places-autocomplete';

// import upload from "../../../../assets/images/upload.png"
import { OutlinedInput, InputLabel, MenuItem, FormControl, Select, Chip } from '@mui/material';
import helper from "./helper";
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 900,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
const names = [
  'Hindi',
  'English',
  'Punjabi',
  'Tamil',
];

function getStyles(name, personName) {

  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? "12px"
        : "2px",
  };
}

class AddNewActivity extends Component {
  constructor() {
    super();
    this.state = {
      flaxedData: { slot_type: [], duration: "", start_time: "", day_quantity: "", duration_quantity: "", itinerary: "", pendingSlot: 0 },
      editPriceIndex: -1,
      websiteData: "",
      priceArr: [],
      modelPrice: false,
      priceTable: { people: 1, price: null },
      activity: { activityDay: "", activityType: "", availability: "", activityFuture: "", is_pickup: "" },
      whatTake: {
        value: "",
        items: []
      },
      thinkServices: {
        value: "",
        items: []
      },
      addOn: {
        price: "",
        item: "",
        items: []
      },
      actFuture: { futureDate: "", futureSpot: "" },
      dateTable: {},
      categoryArr: [],
      subCategoryArr: [],
      modelArr: [],
      form: {
        activity_id: null,
        activity_adventure_type_id: null,
        title: "",
        level: null,
        altitude_depth_height: null,
        age_from: null,
        age_to: null,
        description: "",
        warning: "",
        is_pickup: 0,
        price: [],
        is_extra_charges: 1,
        address_line_one: "",
        address_line_two: "",
        landmark: "",
        country: "",
        state: "",
        city: "",
        pin_code: "",
        latitude: "",
        longitude: "",
        location: "",
        what_to_take: [],
        add_ons: [],
        is_provide_all_parts: "0",
        images: [],
        lat: "",
        lng: "",
        is_website: "0",
        website_link: "",
        list_date: [],
        thing_service_included: [],
        profile_image: [],
        video: "",
        activity_type_data: {
          activity_type: "",
          single_day_categories: "",
          slot_type: "",
          repeat_in_fature: [],
          auto: { start_time: "", slot_time_duration: "", day_slot: "", time_slot: "" },
          flexd: [],
          slot: [],
          activity_repeat_in_future: "0",
          repeat_start_date: "",
          spot: "",
          duration: "",
          start_date: "",
          no_of_spot: "",
          start_time: "",
          end_time: "",
          itinerary: [],
        },
        language: [],
      },
      activity_type_data: {},
      logo_error: '',
      countryVal: "",
      stateVal: "",
      error: {},
      warning: false,
      success: false,
      error_message: ""
    };
  }


  handleSubmitForm = async () => {
    let s1 = { ...this.state }
    let response = await helper.callApi(s1.form)
    // if (response.data.status == 200) {
    //   this.setState({ success: true, error_message: response.data.message })
    // } else {
    //   this.setState({ warning: true, error_message: response.data.message })
    // }
    console.log(response)
  }


  onFilesChange = (files) => {
    let s1 = { ...this.state }
    console.log(files[0])
    if (files[0] && s1.form.profile_image.length <= 3) {
      if (files[0].extension == "mp4") {
        let lo = URL.createObjectURL(files[0])
        s1.form.video = lo
        console.log(lo)
      } else {
        s1.form.images.push(files[0])
        s1.form.profile_image.push(files[0].name)
        s1.logo_error = ""
      }
    } else {

      s1.error.images = "You can only 4 images or 1 video uploaded"
    }
    this.setState(s1)
  }
  onFilesError = (error, file) => {
    this.setState({
      logo_error: error.message + "limit upto 3MB max"
    })
  }

  handleChange1 = (event) => {
    let s1 = { ...this.state }
    const { target: { value } } = event;
    let language = typeof value === 'string' ? value.split(',') : value
    s1.form.language = language
    this.setState(s1)
  };

  handleChange = (event) => {
    const { name, value } = event.target;
    let s1 = { ...this.state }
    s1.form.activity_type_data[name] = value
    this.setState(s1);
  };
  /////////////////////////////////////////////////////////////////

  getCategory = async (url, val) => {
    let s1 = { ...this.state }
    console.log(url)
    http.getList(url)
      .then(result => {
        console.log(result)
        if (result.status == 200) {
          console.log(result.data)
          this.setState({ [val]: result.data })
        } else {
          // setErrMessage(result.message)
        }
      })
      .catch(error => {
        console.log(error)
      });
  }
  componentDidMount() {
    this.getCategory(`v1/vendor/get_activities_by_vendor_selected_category`, "categoryArr")

  }
  handleFormChange = (event) => {
    const { name, value } = event.target;
    let s1 = { ...this.state }
    console.log(value)
    if (name == "country") {
      s1.countryVal = value
      Country.getAllCountries().map(op => {
        if (value == op.isoCode) {
          s1.form.country = op.name
        }
      })
    }
    else if (name == "state") {
      s1.stateVal = value
      State.getStatesOfCountry(s1.countryVal).map(op => {
        if (s1.stateVal == op.isoCode) {
          s1.form.state = op.name
        }
      })
    } else {
      s1.form[name] = value
    }
    this.getCategory(`v1/vendor/get_adventure_activity_types/${s1.form.activity_id}`, "subCategoryArr")
    this.setState(s1);
  }
  onClickAdd = (check) => {
    // console.log(test);
    let s1 = { ...this.state }
    if (check === "whatTake") {
      if (s1.whatTake.value) {
        s1.form.what_to_take.push({ name: s1.whatTake.value })
        s1.whatTake.value = ''
        this.setState(s1)
      }
    }
    else if (check === "thingsInclude") {
      if (s1.thinkServices.value) {
        s1.form.thing_service_included.push({ name: s1.thinkServices.value })
        s1.thinkServices.value = ''
        this.setState(s1)
      }
    } else if (check == "addOn") {
      if (s1.addOn.price && s1.addOn.item) {
        s1.form.add_ons.push({ item: s1.addOn.item, price: s1.addOn.price })
        s1.addOn.price = ''
        s1.addOn.item = ''
        this.setState(s1)
      }
    }
    else if (check == "weblink") {
      console.log(s1.websiteData);
      if (s1.websiteData) {
        s1.form.website_link = s1.websiteData
        s1.websiteData = ""
        this.setState(s1)
      }
    }
    else if (check == "addList") {
      if (s1.dateTable.startDate && s1.dateTable.endDate) {
        s1.form.list_date.push({ start_date: s1.dateTable.startDate, end_date: s1.dateTable.endDate })
        s1.dateTable.startDate = ""
        s1.dateTable.endDate = ""
        this.setState(s1)
      }
    }
    else if (check == "future") {
      if (s1.actFuture.futureDate && s1.actFuture.futureSpot) {
        s1.form.activity_type_data.repeat_in_fature.push({ repeat_start_date: s1.actFuture.futureDate, spot: s1.actFuture.futureSpot })
        s1.actFuture.futureDate = ""
        s1.actFuture.futureSpot = ""
        this.setState(s1)
      }
    }
    else if (check === "addons") {
      const { inputValue2, inputValue3, addons } = this.state;
      // console.log(inputValue);
      if (inputValue2 && inputValue3) {
        const nextState = [...addons, inputValue2 + "($" + inputValue3 + ")"];
        // console.log(nextState);
        this.setState({
          addons: nextState,
          inputValue2: '',
          inputValue3: ''
        });

      }
    }
  }
  onChangeitem = (e) => {
    const { name, value } = e.target
    let s1 = { ...this.state }
    if (name == "whatTake") {
      s1.whatTake.value = value
    } else if (name == "thinkServices") {
      s1.thinkServices.value = value
    } else if (name == "price") {
      s1.addOn.price = value
    } else if (name == "item") {
      s1.addOn.item = value
    } else if (name == "startDate" || name == "endDate") {
      s1.dateTable[name] = value
    } else if (name == "websiteData") {
      s1.websiteData = value
    } else if (name == "futureDate" || name == "futureSpot") {
      console.log(name, value)
      s1.actFuture[name] = value
    }
    this.setState(s1)
  }

  removeItem = (index, check) => {
    let s1 = { ...this.state }
    if (check === "whatTake") {
      s1.form.what_to_take.splice(index, 1)
    }
    else if (check === "thing") {
      s1.form.thing_service_included.splice(index, 1)
      this.setState(s1)
    }
    else if (check === "weblink") {
      let s1 = { ...this.state }
      s1.form.website_link = ""
      this.setState(s1)
    }
    else if (check === "addList") {
      let s1 = { ...this.state }
      s1.form.list_date.splice(index, 1)
      this.setState(s1)
    }
    else if (check === "addons") {
      let s1 = { ...this.state }
      s1.form.add_ons.splice(index, 1)
      this.setState(s1)
    }
    else if (check === "future") {
      let s1 = { ...this.state }
      s1.form.activity_type_data.repeat_in_fature.splice(index, 1)
      this.setState(s1)
    }
    this.setState(s1)
  }

  onChangePrice = (e) => {
    console.log("onchage")
    let s1 = { ...this.state }
    s1.priceTable.price = e.target.value
    this.setState(s1)
  }

  addPrice = () => {
    console.log("add")
    let s1 = { ...this.state }
    if (s1.priceTable.price) {
      if (s1.editPriceIndex > -1) {
        let obj = { no_of_person: s1.priceTable.people, amount: s1.priceTable.price }
        s1.form.price[s1.editPriceIndex] = obj
        s1.priceTable.people = 0
        s1.form.price.map(o => s1.priceTable.people++)
        s1.priceTable.price = ''
        s1.priceTable.people++
        s1.editPriceIndex = -1
      } else {
        let arr = { no_of_person: s1.priceTable.people, amount: s1.priceTable.price }
        s1.form.price.push(arr)
        s1.priceTable.price = ''
        s1.priceTable.people++
      }
    }
    this.setState(s1)
  }
  editPrice = (index) => {
    console.log("edit")
    let s1 = { ...this.state }
    let obj = { people: s1.form.price[index].no_of_person, price: s1.form.price[index].amount }
    s1.priceTable = obj
    s1.editPriceIndex = index
    this.setState(s1)
  }
  reset = () => {
    let s1 = { ...this.state }
    s1.form.price = []
    s1.priceTable = { people: 1, price: null }
    this.setState(s1)
  }
  handleChangeLoc = location => {
    let s1 = { ...this.state }
    s1.form.location = location
    this.setState(s1);
  };

  handleSelect = async (location) => {
    let s1 = { ...this.state }
    let res = await geocodeByAddress(location)
    let lang = await getLatLng(res[0])
    s1.form.location = res[0].formatted_address
    s1.form.lat = lang.lat
    s1.form.lng = lang.lng
    this.setState(s1)
  };

  handleChangeAuto = (name, value, val) => {
    let s1 = { ...this.state }

    if (val == "auto") {
      s1.form.activity_type_data.auto[name] = value
    } else if (val == "singleCat" || val == "slot_type") {
      s1.form.activity_type_data[name] = value
      s1.form.activity_type_data.slot = []
    } else if (name == "itinerary") {
      s1.form.activity_type_data.itinerary[val] = value
    }
    this.setState(s1)
  }
  handleSlots = (val, arr) => {
    let s1 = { ...this.state }
    if (val == "single") {
      s1.form.activity_type_data.slot = arr
    } else if (val == "multi") {
      s1.form.activity_type_data.itinerary = arr
    } else if (val == "flex") {
      s1.form.activity_type_data.slot = arr
    } else if (val == "flexData") {
      // let arr1 = 
      s1.form.activity_type_data.flexd.push(arr)
    }
    console.log("lkllk")
    this.setState(s1)
  }
  handleFlaxedSlot = (e) => {
    let s1 = { ...this.state }
    const { name, value } = e.target
    if (name == "slot_type") {
      if (s1.flaxedData.slot_type.find(o => o == value)) {
        s1.flaxedData.slot_type.splice(s1.flaxedData.slot_type.findIndex(op => op == value), 1)
        if (s1.form.activity_type_data.flexd.length != 0) {
          if (s1.form.activity_type_data.flexd.find(h => h.slot_type == value)) {
            s1.form.activity_type_data.flexd.splice(s1.form.activity_type_data.flexd.findIndex(l => l.slot_type == value), 1)
            if(s1.form.activity_type_data.slot.find(op=>op.slot_type==value)){
              s1.form.activity_type_data.slot.splice(s1.form.activity_type_data.slot.findIndex(l => l.slot_type == value), 1)
            }
          }
        }
      } else {
        s1.flaxedData.slot_type.push(value)
      }
    } else {
      if (name == "day_quantity") {
        s1.flaxedData.pendingSlot = value
      }
      s1.flaxedData[name] = value
    }
    console.log(s1.flaxedData.slot_type)
    this.setState(s1)
  }



  render() {
    const { activity, whatTake, priceArr, priceTable, warning, thinkServices, addOn, form, success, error_message, inputValue, item_takes, inputValue1, error, inputValue5, weblink, inputValue2, inputValue3, addons, successfull } = this.state;
    // const theme = useTheme();
    console.log(form.list_date)
    let center = {
      lat: this.state.form.lat,
      lng: this.state.form.lng
    }
    let zoom = 15
    console.log(form)
    return (<>
      {warning ? <SweetAlert
        warning
        // showCancel
        // style={{ backgroundColor: 'black', color: 'white' }}
        confirmBtnText="OK"
        confirmBtnBsStyle="danger"
        title={error_message}
        onConfirm={() => this.setState({ warning: false, error_message: "" })}
        // onCancel={this.onCancel}
        focusCancelBtn
      >
      </SweetAlert> : ""
      }
      {
        success ?
          <SweetAlert
            success
            title={error_message}
            // style={{ backgroundColor: 'black', color: 'white' }}
            confirmBtnBsStyle={'danger'}
            onConfirm={() => this.props.history.push("/myactivity")}
          // onCancel={this.onCancel}
          >
          </SweetAlert> : ""}


      <div className="p-5">
        <Breadcrumb>
          <Link className="breadcrumb_link" to="/myActivity">My Activity /</Link>
          <Link className="breadcrumb_link active" to="/mynewactivity">Add New Activity </Link>
        </Breadcrumb>


        <div className="mainfile">
          <Form>
            <div className="formcolr">
              <Row>
                <Row>
                  <Col lg={6} md={6} sm={12}>
                    <Row>
                      <Col lg={6} md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Category</Form.Label>
                          <Form.Select aria-label="Default select example" name="activity_id" value={this.state.form.activity_id} onChange={this.handleFormChange}>
                            <option selected>Select Category</option>
                            {this.state.categoryArr && this.state.categoryArr.map(op => (
                              <option value={op.id}>{op.title}</option>
                            ))}
                          </Form.Select>
                        </div>
                      </Col>
                      <Col lg={6} md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Sub-Category</Form.Label>
                          <Form.Select aria-label="Default select example" name="activity_adventure_type_id" value={this.state.form.activity_adventure_type_id} onChange={this.handleFormChange}>
                            <option selected>Select Category</option>
                            {
                              this.state.subCategoryArr.map(op => (
                                <option value={op.id}>{op.name}</option>
                              ))
                            }
                          </Form.Select>
                        </div>
                      </Col>
                      <Col lg={6} md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Title</Form.Label>
                          <Form.Control className="cus" type="text" name="title" value={this.state.form.title} onChange={this.handleFormChange} placeholder="Enter Title" />
                        </div>
                      </Col>
                      <Col lg={6} md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Level</Form.Label>
                          <Form.Select aria-label="Default select example" name="level" value={this.state.form.level} onChange={this.handleFormChange}>
                            <option selected>Select Level</option>
                            <option value="1">Beginner</option>
                            <option value="2">Intermediate</option>
                            <option value="3">Expert</option>
                          </Form.Select>
                        </div>
                      </Col>
                      <Col lg={6} md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Age from</Form.Label>
                          <Form.Control className="cus" type="number" name="age_from" value={this.state.form.age_from} onChange={this.handleFormChange} placeholder="From Age" />
                        </div>
                      </Col>

                      <Col lg={6} md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Age to</Form.Label>
                          <Form.Control className="cus" type="number" name="age_to" value={this.state.form.age_to} onChange={this.handleFormChange} placeholder="From Age" />
                        </div>
                      </Col>
                      <Col lg={6} md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Altitude/Depth/Height</Form.Label>
                          <div class="sel">
                            <Form.Control className="cus" type="number" name="altitude_depth_height" value={this.state.form.altitude_depth_height} onChange={this.handleFormChange} placeholder="Enter Here" />
                            <Form.Select aria-label="Default select example">
                              <option selected>Height</option>
                              <option value="1">One</option>
                              <option value="2">Two</option>
                              <option value="3">Three</option>
                            </Form.Select>
                          </div>
                        </div>
                      </Col>
                      <Col lg={6} md={6} sm={12}>
                        <div className="editform">
                          {/* <Form.Label className="form-label">Language</Form.Label> */}
                          <div>
                            <FormControl sx={{ m: 1, width: 300 }}>
                              <InputLabel id="demo-multiple-chip-label">Language</InputLabel>
                              <Form.Select aria-label="Default select example">
                                <option selected>Select</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                              </Form.Select>
                            </FormControl>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <div className="singleAct-container">
                      <h6 class="meefont text-white bfont"> Price Table</h6>
                      <div className="editform">
                        {/* <label>{priceTable.people}</label>
                        <input type="number" placeholder="Enter Price" name="price" value={priceTable.price} onChange={this.onChangePrice} />
                        <button className="addbut" type="button" onClick={() => this.addPrice()} >{this.state.editPriceIndex > -1 ? "Change" : "Add"}</button> */}
                        <Form.Label className="form-label">No of People</Form.Label>
                        <Form.Label className="d-flex detail">
                          <Form.Control className="enteita me-2" type="text" value={priceTable.people} />
                          <Form.Control class="enteita mx-2" type="number" placeholder="Enter Price" name="price" value={priceTable.price} onChange={this.onChangePrice} />
                          <button className="addbut" type="button" onClick={() => this.addPrice()} >{this.state.editPriceIndex > -1 ? "Change" : "Add"}</button>
                        </Form.Label>
                        <div className="d-flex justify-content-between align-items-center mt-3">
                          <ul className="addlist p-">
                            {form.price && form.price.map((op, index) => (
                              <li onClick={() => this.editPrice(index)}>No of People : {op.no_of_person} , Price : {op.amount} &nbsp; &nbsp;<i class="fa fa-edit text-danger" aria-hidden="true"></i></li>
                            ))}
                          </ul>
                          {form.price.length == 0 ? "" : <div className="editform"> <Form.Label><button className="btn btn-danger" type="button" onClick={() => this.reset()} >Reset</button></Form.Label></div>}
                        </div>
                      </div>
                    </div>
                    {/* 
                    <Row className="singleAct-container">
                      <h6>Price</h6>
                      <Col lg={4} md={4} sm={12}>
                        <p>No of People: <span>1</span></p>
                      </Col>
                      <Col lg={8} md={8} sm={8}>

                        <div className="editform">
                          <Form.Label className="d-flex bordedit">
                            <Form.Control type="text" className="cus" placeholder="Enter Price" />
                            <button className="addbut" type="button" >Add</button>
                          </Form.Label>
                        </div>
                      </Col>
                    </Row> */}
                  </Col>
                </Row>





                <Col lg={12} md={12} sm={12}>
                  <div className="editform">
                    <Form.Label className="form-label">Highlight</Form.Label>
                    <textarea className="form-control" name="description" value={this.state.form.description} onChange={this.handleFormChange} placeholder="Enter here"></textarea>
                  </div>
                </Col>
                <Col lg={12} md={12} sm={12}>
                  <div className="editform">
                    <Form.Label className="form-label">Warning</Form.Label>
                    <textarea className="form-control" name="warning" value={this.state.form.warning} onChange={this.handleFormChange} placeholder="Enter here"></textarea>
                  </div>
                </Col>
              </Row>
              {/* <hr className="text-white" /> */}
              <Row className="singleAct-container">
                <Col lg={12} md={12} sm={12}>
                  <div className="editform">
                    <Form.Label className="form-label">PickUp</Form.Label>
                    <div className="d-flex w-100">
                      <div className="form-check pe-5 d-flex align-items-center">
                        <input className="form-check-input" type="radio" name="is_pickup" value="1" checked={this.state.form.is_pickup == 1} id="flexRadioDefault1" onChange={this.handleFormChange} />
                        <Form.Label className="form-check-label text-white ms-2" for="flexRadioDefault1">
                          Yes
                        </Form.Label>
                      </div>
                      <div className="form-check d-flex align-items-center">
                        <input className="form-check-input " type="radio" name="is_pickup" value="0" checked={this.state.form.is_pickup == 0} id="flexRadioDefault1" onChange={this.handleFormChange} />
                        <Form.Label className="form-check-label text-white ms-2" for="flexRadioDefault1">
                          No
                        </Form.Label>
                      </div>
                    </div>
                  </div>
                  <div className="editform">

                    {this.state.form.is_pickup == 1 && <div className="d-flex w-100">
                      <div className="form-check pe-5 d-flex align-items-center">
                        <Form.Control className="form-check-input" type="radio" name="is_extra_charges" value="1" id="flexRadioDefault1" onChange={this.handleChange} />
                        <Form.Label className="form-check-label text-white ms-2" for="flexRadioDefault1">
                          Extra Charges
                        </Form.Label>
                      </div>
                      <div className="form-check d-flex align-items-center">
                        <Form.Control className="form-check-input " type="radio" name="is_extra_charges" value="0" id="flexRadioDefault1" onChange={this.handleChange} />
                        <Form.Label className="form-check-label text-white ms-2" for="flexRadioDefault1">
                          Free
                        </Form.Label>
                      </div>
                    </div>}
                  </div>
                </Col>
                {this.state.form.is_pickup == 1
                  && <><Col lg={7} md={12} sm={12}>
                    <h6 className="meefont text-white bfont">Meeting Point</h6>
                    <Row>
                      <Col md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Address1</Form.Label>
                          <Form.Control type="text" className="cus" name="address_line_one" value={form.address_line_one} onChange={this.handleFormChange} placeholder="Enter Address Line 1" />
                        </div>
                      </Col>
                      <Col md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Address2</Form.Label>
                          <Form.Control type="text" className="cus" name="address_line_two" value={form.address_line_two} onChange={this.handleFormChange} placeholder="Enter Address Line 2" />
                        </div>
                      </Col>
                      <Col md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Land mark</Form.Label>
                          <Form.Control type="text" className="cus" name="landmark" value={form.landmark} onChange={this.handleFormChange} placeholder="Enter Landmark" />
                        </div>
                      </Col>
                      <Col md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Location</Form.Label>
                          <PlacesAutocomplete
                            value={this.state.form.location}
                            onChange={this.handleChangeLoc}
                            onSelect={this.handleSelect}
                          >
                            {({ getInputProps, suggestions, getSuggestionItemProps, loading }) => (
                              <div>
                                <input
                                  {...getInputProps({
                                    placeholder: 'Please Search and Select Location',
                                    className: 'form-control',
                                  })}
                                />
                                <div className="autocomplete-dropdown-container">
                                  {loading && <div>Loading...</div>}
                                  {suggestions.map(suggestion => {
                                    const className = suggestion.active
                                      ? 'suggestion-item--active'
                                      : 'suggestion-item';
                                    // inline style for demonstration purpose
                                    const style = suggestion.active
                                      ? { backgroundColor: '#fafafa', cursor: 'pointer' }
                                      : { backgroundColor: '#ffffff', cursor: 'pointer' };
                                    return (
                                      <div
                                        {...getSuggestionItemProps(suggestion, {
                                          className,
                                          style,
                                        })}
                                      >
                                        <span>{suggestion.description}</span>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            )}
                          </PlacesAutocomplete>
                        </div>
                      </Col>
                      <Col md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Country</Form.Label>
                          <Form.Select aria-label="Default select example" name="country" value={form.country} onChange={this.handleFormChange}>
                            <option >{form.country ? form.country : "Select"}</option>
                            {Country.getAllCountries().map(op => (
                              <option value={op.isoCode}>{op.name}</option>
                            ))}

                          </Form.Select>
                        </div>
                      </Col>
                      <Col md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">State</Form.Label>
                          <Form.Select aria-label="Default select example" name="state" value={form.state} onChange={this.handleFormChange}>
                            <option >{form.state ? form.state : "Select"}</option>
                            {this.state.countryVal &&
                              State.getStatesOfCountry(this.state.countryVal).map(op => (
                                <option value={op.isoCode}>{op.name}</option>
                              ))}

                          </Form.Select>
                        </div>
                      </Col>
                      <Col md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">City</Form.Label>
                          <Form.Select aria-label="Default select example" name="city" value={form.city} onChange={this.handleFormChange}>
                            <option >{form.city ? form.city : "Select"}</option>
                            {this.state.countryVal && this.state.stateVal &&
                              City.getCitiesOfState(this.state.countryVal, this.state.stateVal).map(op => (
                                <option value={op.name}>{op.name}</option>
                              ))}

                          </Form.Select>
                        </div>
                      </Col>

                      <Col md={6} sm={12}>
                        <div className="editform">
                          <Form.Label className="form-label">Pin Code</Form.Label>
                          <Form.Control type="text" className="cus" name="pin_code" value={form.pin_code} onChange={this.handleFormChange} placeholder="Enter Code" />
                        </div>
                      </Col>

                    </Row>
                  </Col>
                    <Col lg={5} md={12} sm={12}>
                      <div className="editform box_detail map_box">
                        <Form.Label className="form-label">Location</Form.Label>
                        <div style={{ height: '60%', width: '100%', border: "0" }}>
                          <GoogleMapReact
                            bootstrapURLKeys={{ key: "AIzaSyCfrf66IDi6arrcCt7NlxTIWDKaa66a6Ns" }}
                            defaultCenter={center}
                            defaultZoom={zoom}
                          >
                            <div
                              lat={59.955413}
                              lng={30.337844}
                              text="My Marker"
                            />
                          </GoogleMapReact>
                        </div>
                        {/* <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15282225.79979123!2d73.7250245393691!3d20.750301298393563!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30635ff06b92b791%3A0xd78c4fa1854213a6!2sIndia!5e0!3m2!1sen!2sin!4v1587818542745!5m2!1sen!2sin" width="100%" height="60%" frameborder="0" style={{ border: 0 }} allowfullscreen="" aria-hidden="false" tabindex="0"></iframe> */}

                      </div>
                    </Col></>}
              </Row>
              {/* <hr className="text-white" /> */}
              <Row className="pt-4">
                <Col lg={6} md={12} sm={12}>
                  <div className="editform">
                    <Form.Label className="form-label">What to Take</Form.Label>
                    <Form.Label className="d-flex bordedit">
                      <Form.Control className="enteita" type="text" name="whatTake" placeholder="Enter Item" value={whatTake.value} onChange={this.onChangeitem} />
                      <button className="addbut" type="button" onClick={() => this.onClickAdd('whatTake')}>Add</button>
                    </Form.Label>
                    <ul className="addlist p-0">
                      {form.what_to_take && form.what_to_take.map((item, index) => (
                        <li onClick={() => this.removeItem(index, 'whatTake')}>{item.name} &nbsp; &nbsp;<i class="fa fa-times" aria-hidden="true"></i></li>
                      ))}
                    </ul>
                  </div>
                </Col>
                <Col lg={6} md={12} sm={12}>
                  <div className="editform">
                    <Form.Label className="form-label">Things and services included</Form.Label>
                    <Form.Label className="d-flex bordedit">
                      <Form.Control className="enteita" type="text" placeholder="Enter Item" name="thinkServices" value={thinkServices.value} onChange={this.onChangeitem} />
                      <button className="addbut" type="button" onClick={() => this.onClickAdd('thingsInclude')}>Add</button>
                    </Form.Label>
                    <ul className="addlist p-0">
                      {form.thing_service_included && form.thing_service_included.map((thing, index) => (
                        <li onClick={() => this.removeItem(index, 'thing')}>{thing.name} &nbsp; &nbsp;<i class="fa fa-times" aria-hidden="true"></i></li>
                      ))}
                    </ul>
                  </div>
                </Col>
                <Col lg={6} md={12} sm={12}>
                  <h6 class="meefont text-white bfont">Add Ons</h6>
                  <div className="editform">
                    <Form.Label className="form-label">Item</Form.Label>
                    <Form.Label className="d-flex detail">
                      <Form.Control className="enteita me-2" type="text" placeholder="Enter Item" name="item" value={addOn.item} onChange={this.onChangeitem} />
                      <Form.Control class="enteita mx-2" type="number" placeholder="Enter Price" name="price" value={addOn.price} onChange={this.onChangeitem} />
                      <button className="addbut" type="button" onClick={() => this.onClickAdd('addOn')} >Add</button>
                    </Form.Label>
                    <ul className="addlist p-0">
                      {form.add_ons && form.add_ons.map((addon, index) => (
                        <li onClick={() => this.removeItem(index, 'addons')}>{addon.item}({addon.price}) &nbsp; &nbsp;<i class="fa fa-times" aria-hidden="true"></i></li>
                      ))}
                    </ul>
                  </div>
                </Col>
              </Row>
              {/* <hr className="text-white" /> */}

              <Row className="singleAct-container">
                <Col lg={12} md={12} sm={12}>
                  <div className="editform">
                    <Form.Label className="form-label">Activity Type</Form.Label>
                    <div className="w-100">
                      <Container>
                        <Row className="pt-3">
                          <Col md={6}>
                            <div className="form-check ">
                              <input className="form-check-input" type="radio" id="flexRadioDefault1" checked={this.state.form.activity_type_data.activity_type == "1"} name="activity_type" value="1" onChange={this.handleChange} />
                              <Form.Label className="form-check-label text-white ms-2" for="flexRadioDefault1">
                                Single Day
                              </Form.Label>
                            </div>
                          </Col>
                          <Col md={6}>
                            <div className="form-check ">
                              {/* <Form.Control className="form-check-input" type="radio" name="flexRadioDefault"
                              // id="flexRadioDefault1" /> */}
                              <input className="form-check-input" type="radio" name="activity_type" checked={this.state.form.activity_type_data.activity_type == "2"} value="2" id="flexRadioDefault1" onChange={this.handleChange} />
                              <Form.Label className="form-check-label text-white ms-2" for="flexRadioDefault1">
                                Multiple Day
                              </Form.Label>
                            </div>
                          </Col>
                        </Row>
                      </Container>

                      <Container >
                        <Row>
                          <Col md={12}>

                            {this.state.form.activity_type_data.activity_type == "1"
                              && <SingleDay
                                flaxedData={this.state.flaxedData}
                                handleFlaxed={this.handleFlaxedSlot}
                                handleSlots={this.handleSlots}
                                handleChange={this.handleChange}
                                activity={this.state.form.activity_type_data}
                                handleChangeAuto={this.handleChangeAuto}
                                slots={this.state.form.activity_type_data.slot}
                                auto={this.state.form.activity_type_data.auto} />}
                          </Col>
                          <Col md={12}>
                            {this.state.form.activity_type_data.activity_type == "2"
                              && <MultiDay
                                activity={form.activity_type_data}
                                actFuture={this.state.actFuture}
                                onChangeitem={this.onChangeitem}
                                removeItem={this.removeItem}
                                onClickAdd={this.onClickAdd}
                                showSlots={this.handleSlots}
                                handleItinerary={this.handleChangeAuto}
                                itinerary={form.activity_type_data.itinerary}
                                handleChange={this.handleChange} />}
                          </Col>
                        </Row>
                      </Container>
                    </div>
                  </div>
                </Col>
              </Row>
              {/* <hr className="text-white" /> */}
              {/* <Col lg={12} md={12} sm={12} className="pt-2">
                <div class="editform d-flex">
                  <div className="imagform">
                    <Form.Label class="form-label">Upload Image</Form.Label>
                    <ul class="imgedit p-0 pt-4">
                      <li class="active my-2 me-2">Vertical Image</li>
                      <li>Horizontal Image</li>
                    </ul>
                  </div>
                  <div className="videoform my-2 ms-3 ">
                    <Form.Label class="form-label">Upload video</Form.Label>
                    <ul class="imgedit p-0 pt-4">
                      <li class="active">Upload</li>
                    </ul>
                  </div>
                </div>
              </Col> */}


              <div class="editform d-flex mt-3">
                <div className="imagform">
                  <Form.Label class="form-label">Upload Media</Form.Label>
                  <ul class="imgedit p-0">
                    <li class="active my-2 me-2">
                      <Files
                        className='files-dropzone'
                        onChange={this.onFilesChange}
                        onError={this.onFilesError}
                        // accepts={['.pdf', '.docx', '.doc']}
                        accepts={['image/*']}
                        multiple={false}
                        maxFileSize={10000000}
                        minFileSize={0}
                        clickable
                        style={{ cursor: "pointer" }}
                        required
                      >

                        click to upload Image
                      </Files>
                    </li>
                    <li><Files
                      className='files-dropzone'
                      onChange={this.onFilesChange}
                      onError={this.onFilesError}
                      // accepts={['.pdf', '.docx', '.doc']}
                      accepts={['video/mp4']}
                      multiple={false}
                      maxFileSize={10000000}
                      minFileSize={0}
                      clickable
                      style={{ cursor: "pointer" }}
                      required
                    >

                      click to upload video
                    </Files></li>
                  </ul>
                </div>
                {/* <div className="videoform my-2 ms-3">
                                    {/* <Form.Label class="form-label">Upload video</Form.Label> */}
                {/* <ul class="imgedit p-0">
                                    <li class="active">

                                    </li>
                                </ul>
                            </div> */}
              </div>
              <div >
                <Row className="img_box">
                  {this.state.form.images.length != 0 || this.state.form.video
                    ? <Files
                      className='files-dropzone'
                      onChange={this.onFilesChange}
                      onError={this.onFilesError}
                      // accepts={['.pdf', '.docx', '.doc']}
                      accepts={['image/*', 'video/mp4']}
                      multiple={false}
                      maxFileSize={10000000}
                      minFileSize={0}
                      clickable
                      style={{ cursor: "pointer" }}
                      required
                    ><Row>
                        {this.state.form.images.map(op => (
                          <Col md={2}>
                            <img src={op.preview.url} alt="" />
                          </Col>
                        ))}
                        {this.state.form.video
                          &&
                          <Col md={2}>
                            <video width="90" controls src={this.state.form.video} type="video/mp4">
                              {/* <source src={this.state.form.video} type="video/mp4"> */}
                              {/* <source src="mov_bbb.ogg" type="video/ogg"> */}
                              Your browser does not support HTML video.
                            </video>
                          </Col>}

                      </Row>
                    </Files>
                    : <>
                      <Files
                        className='files-dropzone'
                        onChange={this.onFilesChange}
                        onError={this.onFilesError}
                        // accepts={['.pdf', '.docx', '.doc']}
                        accepts={['image/*', 'video/mp4']}
                        multiple={false}
                        maxFileSize={10000000}
                        minFileSize={0}
                        clickable
                        style={{ cursor: "pointer" }}
                        required
                      >
                        <Row>
                          <Col md={1}><img src={upload} /></Col>
                          <Col md={1}><img src={upload} /></Col>
                          <Col md={1}><img src={upload} /></Col>
                        </Row>
                      </Files>
                    </>}

                </Row>
                {error && error.images ? <><span className="text-danger">{error.images}</span></> : ""}
              </div>

              <Row>
                <Col lg={6} md={12} sm={12}>
                  <h6 className="meefont text-white bfont">List Date</h6>
                  <Row>
                    <Col md={5}>
                      <div className="editform">
                        <Form.Label className="form-label">Start Date</Form.Label>
                        <form className="d-flex detail">
                          <Form.Control className="dateedit" name="startDate" value={this.state.dateTable.startDate} onChange={this.onChangeitem} type="date" />
                        </form>
                      </div>
                    </Col>
                    <Col md={5}>
                      <div className="editform">
                        <Form.Label className="form-label">End Date</Form.Label>
                        <form className="d-flex detail">
                          <Form.Control className="dateedit" name="endDate" value={this.state.dateTable.endDate} onChange={this.onChangeitem} type="date" />
                        </form>
                      </div>
                    </Col>
                    <Col md={2}>
                      <div className="editform">
                        <Form.Label className="form-label"></Form.Label>
                        <form className="d-flex detail">
                          <button type="button" className="addbut" onClick={() => this.onClickAdd('addList')}>Add</button>
                        </form>
                      </div>
                    </Col>
                    <div className="editform">
                      <ul className="addlist p-0">
                        {form.list_date && form.list_date.map((item, index) => (
                          <li onClick={() => this.removeItem(index, 'addList')}>{item.start_date} - {item.end_date} &nbsp; &nbsp;<i class="fa fa-times" aria-hidden="true"></i></li>
                        ))}
                      </ul>
                    </div>
                  </Row>
                  <Row>
                    <Col md={12} sm={12}>
                      <Row>
                        <Col md={12} sm={12}>
                          <div className="editform">
                            <Form.Label className="form-label">Will your company provider all the parts of this activity</Form.Label>
                            <div className="d-flex w-100">
                              <div className="form-check pe-5">
                                <Form.Control className="form-check-input" type="radio" name="is_provide_all_parts" value="1" onChange={this.handleFormChange}
                                  id="flexRadioDefault1" />
                                <Form.Label className="form-check-label text-white ms-2" for="flexRadioDefault1">
                                  Yes
                                </Form.Label>
                              </div>
                              <div className="form-check">
                                <Form.Control className="form-check-input" type="radio" name="is_provide_all_parts" value="0" onChange={this.handleFormChange}
                                  id="flexRadioDefault1" />
                                <Form.Label className="form-check-label text-white ms-2" for="flexRadioDefault1">
                                  No
                                </Form.Label>
                              </div>
                            </div>
                          </div>
                        </Col>
                        <Col md={12} sm={12}>
                          <div className="editform">
                            <Form.Label className="form-label">Do you have wbsite?</Form.Label>
                            <div className="d-flex w-100">
                              <div className="form-check pe-5">
                                <Form.Control className="form-check-input" type="radio" name="is_website" value="1" onChange={this.handleFormChange}
                                  id="flexRadioDefault1" />
                                <Form.Label className="form-check-label text-white ms-2" for="flexRadioDefault1">
                                  Yes
                                </Form.Label>
                              </div>
                              <div className="form-check">
                                <Form.Control className="form-check-input" type="radio" name="is_website" value="0" onChange={this.handleFormChange}
                                  id="flexRadioDefault1" />
                                <Form.Label className="form-check-label text-white " for="flexRadioDefault1">
                                  No
                                </Form.Label>
                              </div>
                            </div>
                          </div>
                          {form.is_website && form.is_website == "1"
                            && <div className="editform">
                              <Form.Label className="form-label">If yes enter website link</Form.Label>
                              <form className="d-flex adddeta">
                                <Form.Control className="enteita me-2" type="text" placeholder="Enter Link" name="websiteData" value={this.state.websiteData} onChange={this.onChangeitem} />
                                <button className="addbut" type="button" onClick={() => this.onClickAdd('weblink')}>Add</button>
                              </form>
                              <ul className="addlist p-0">
                                {form.website_link && <li onClick={() => this.removeItem('weblink')}>{form.website_link} &nbsp; &nbsp;<i class="fa fa-times" aria-hidden="true"></i></li>
                                }
                                {/* {weblink && weblink.map((item, index) => (
                                  <li onClick={() => this.removeItem(index, 'weblink')}>{item} &nbsp; &nbsp;<i class="fa fa-times" aria-hidden="true"></i></li>
                                ))} */}
                              </ul>
                            </div>}
                          {/* <div className="editform">
                          <Form.Label className="form-label">If yes enter website link</Form.Label>
                          <form className="d-flex adddeta">
                            <Form.Control className="enteita me-2" type="text" placeholder="Enter Link" />
                            <button className="addbut">Add</button>
                          </form>
                          <ul className="addlinks p-0">
                            <li>www.somthing.com &nbsp; &nbsp;<i class="fa fa-times" aria-hidden="true"></i></li>
                          </ul>
                        </div> */}
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                </Col>
              </Row>
              <hr className="text-white" />
              <Row>
                <Col lg={2} md={4} >
                  <div class="addbutt mb-2">
                    <button type="button" className="custom_btn" onClick={() => this.handleSubmitForm()}>Submit</button>
                  </div>
                </Col>
              </Row>
            </div>
          </Form>
        </div>




      </div >



    </>)
  }


}
export default AddNewActivity;